# Apex Stick Trainer — Android Native v0.2

This revision rebuilds the drill around a clean Aim-Lab-style space and a stricter linear controller path.

## What changed in v0.2

- **360° tracking drill**
  - The tracking target is a real world-space target moving continuously on a full ring around the player.
  - No front wall and no left/right target boundary.
  - Fixed-speed or random-speed mode.
  - Random mode draws a speed between the configured minimum/maximum and can reverse direction at each interval.

- **Minimal visual environment**
  - Removed the room, target wall, wall frame and floor grid.
  - Only floating targets + center crosshair remain, reducing visual clutter.

- **Six-target drill with an invisible boundary**
  - Six targets float in space.
  - The spawn region is an angular virtual box centered on the player's view when entering/resetting the drill.
  - The boundary itself is never rendered.

- **Corrected FOV projection**
  - `120` is treated as **horizontal FOV**.
  - The renderer converts horizontal FOV to the vertical FOV required by the OpenGL perspective matrix.
  - This substantially reduces the previous phone-landscape "fisheye" look.

- **Stricter linear right-stick path**
  - Right-stick calibration stores center + right + left + up + down endpoints.
  - Center→right and center→left are normalized independently; same for up/down.
  - This is piecewise-linear and handles asymmetric physical travel better than one shared scale.
  - Response exponent defaults to **1.00**, which is exactly `output = input`.
  - No smoothing and no acceleration are added.
  - Deadzone remains 0 by default.
  - Camera integration now runs on the render loop instead of a separate UI timer, reducing timing jitter.

## Defaults

- Hip sensitivity: 4.0
- ADS sensitivity: 3.0
- Horizontal FOV: 120°
- Deadzone: 0
- Response exponent: 1.00 (strict linear)
- Per-sensitivity full-stick rate: 60°/s
  - Hip 4.0 => 240°/s full-stick starting point
  - ADS 3.0 => 180°/s full-stick starting point

These are starting values, not a claim of exact Apex Legends internal sensitivity equivalence.

## Build

Open the project in Android Studio with JDK 17. Install Android SDK 35 if prompted, then use **Build > Build APK(s)**.

The environment used to author this project does not include the Android SDK, so an APK is not compiled here.
