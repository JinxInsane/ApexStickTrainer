package com.openai.apexsticktrainer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import java.util.Locale;

public class HudView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final GameState state;
    private final ControllerInput input;

    public HudView(Context c, GameState s, ControllerInput i) {
        super(c);
        state = s;
        input = i;
        p.setTypeface(android.graphics.Typeface.MONOSPACE);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;

        p.setStrokeWidth(3f);
        p.setColor(0xffffffff);
        c.drawLine(cx - 11, cy, cx - 3, cy, p);
        c.drawLine(cx + 3, cy, cx + 11, cy, p);
        c.drawLine(cx, cy - 11, cx, cy - 3, p);
        c.drawLine(cx, cy + 3, cx, cy + 11, p);

        p.setTextSize(25f);
        String mode = state.mode == GameState.Mode.TRACKING ? "360跟枪" : "六目标";
        String extra = state.mode == GameState.Mode.TRACKING
                ? String.format(Locale.US, "  靶速 %.1f°/s", Math.abs(state.getTrackingSpeedSigned()))
                : String.format(Locale.US, "  虚拟边界 %.0f×%.0f°", state.sixBoundaryWidthDeg, state.sixBoundaryHeightDeg);

        String line = String.format(Locale.US,
                "%s  HFOV %.0f  LIN %.2f  命中 %d/%d%s",
                mode,
                state.fovDeg,
                state.responseExponent,
                state.hits,
                state.shots,
                extra);
        c.drawText(line, 22f, 38f, p);

        p.setTextSize(18f);
        String stick = String.format(Locale.US,
                "RX %.3f  RY %.3f",
                input.getRightX(),
                input.getRightY());
        c.drawText(stick, 22f, 66f, p);

        invalidate();
    }
}
