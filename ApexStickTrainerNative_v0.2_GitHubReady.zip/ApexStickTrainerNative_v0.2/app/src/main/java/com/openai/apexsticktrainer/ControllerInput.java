package com.openai.apexsticktrainer;

import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ControllerInput {
    /**
     * Calibration stores the raw center plus the raw endpoint for each semantic
     * direction. Each half-axis is then mapped independently to [-1, 0] or [0, 1].
     * This avoids the old "one scale for both sides" behavior and keeps the map
     * piecewise-linear even when the hardware's left/right travel is asymmetric.
     */
    public static class AxisMap {
        public int xAxis = MotionEvent.AXIS_Z;
        public int yAxis = MotionEvent.AXIS_RZ;

        public float xCenter = 0f;
        public float xRightRaw = 1f;
        public float xLeftRaw = -1f;

        public float yCenter = 0f;
        public float yDownRaw = 1f;
        public float yUpRaw = -1f;
    }

    private final AxisMap map = new AxisMap();
    private final Map<Integer, Float> lastAxes = new HashMap<>();

    private volatile float rightX;
    private volatile float rightY;
    private volatile boolean shootPressed;
    private volatile boolean adsPressed;
    private volatile int deviceId = -1;

    public AxisMap getMap() { return map; }
    public float getRightX() { return clamp(rightX, -1f, 1f); }
    public float getRightY() { return clamp(rightY, -1f, 1f); }
    public boolean isShootPressed() { return shootPressed; }
    public boolean isAdsPressed() { return adsPressed; }
    public int getDeviceId() { return deviceId; }

    public boolean onMotionEvent(MotionEvent e) {
        int source = e.getSource();
        if ((source & InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK &&
            (source & InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD) return false;

        deviceId = e.getDeviceId();
        InputDevice d = e.getDevice();
        if (d != null) {
            List<InputDevice.MotionRange> ranges = d.getMotionRanges();
            for (InputDevice.MotionRange r : ranges) {
                if ((r.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK ||
                    (r.getSource() & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD) {
                    lastAxes.put(r.getAxis(), e.getAxisValue(r.getAxis()));
                }
            }
        }

        rightX = normalizeDirectional(
                e.getAxisValue(map.xAxis),
                map.xCenter,
                map.xRightRaw,
                map.xLeftRaw);

        rightY = normalizeDirectional(
                e.getAxisValue(map.yAxis),
                map.yCenter,
                map.yDownRaw,
                map.yUpRaw);

        // Common Android trigger representations.
        float rTrig = Math.max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS));
        float lTrig = Math.max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE));
        if (rTrig > 0.35f) shootPressed = true;
        else if (rTrig >= 0f) shootPressed = false;
        if (lTrig > 0.35f) adsPressed = true;
        else if (lTrig >= 0f) adsPressed = false;

        return true;
    }

    public boolean onKeyEvent(KeyEvent e) {
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        if (e.getKeyCode() == KeyEvent.KEYCODE_BUTTON_R2) {
            shootPressed = down;
            return true;
        }
        if (e.getKeyCode() == KeyEvent.KEYCODE_BUTTON_L2) {
            adsPressed = down;
            return true;
        }
        return false;
    }

    public Map<Integer, Float> snapshotAxes() {
        return new HashMap<>(lastAxes);
    }

    public void applyCalibration(int xAxis, int yAxis,
                                 float xCenter, float xRightRaw, float xLeftRaw,
                                 float yCenter, float yDownRaw, float yUpRaw) {
        map.xAxis = xAxis;
        map.yAxis = yAxis;
        map.xCenter = xCenter;
        map.xRightRaw = xRightRaw;
        map.xLeftRaw = xLeftRaw;
        map.yCenter = yCenter;
        map.yDownRaw = yDownRaw;
        map.yUpRaw = yUpRaw;
    }

    public String diagnostics() {
        StringBuilder b = new StringBuilder();
        b.append("device=").append(deviceId)
         .append("  RX=").append(String.format(Locale.US, "%.3f", rightX))
         .append(" RY=").append(String.format(Locale.US, "%.3f", rightY)).append("\n");
        for (Map.Entry<Integer, Float> en : lastAxes.entrySet()) {
            b.append("A").append(en.getKey()).append("=")
             .append(String.format(Locale.US, "%.3f", en.getValue())).append("  ");
        }
        return b.toString();
    }

    private static float normalizeDirectional(float raw, float center, float positiveRaw, float negativeRaw) {
        float posDelta = positiveRaw - center;
        float negDelta = negativeRaw - center;
        float rawDelta = raw - center;

        if (Math.abs(posDelta) < 0.01f || Math.abs(negDelta) < 0.01f) {
            return clamp(rawDelta, -1f, 1f);
        }

        // Convert raw movement into semantic sign: + means right/down, - means left/up.
        float positiveSign = Math.signum(posDelta);
        float semanticDelta = rawDelta * positiveSign;
        float posRange = Math.abs(posDelta);
        float negRange = Math.abs(negDelta);

        float out = semanticDelta >= 0f ? semanticDelta / posRange : semanticDelta / negRange;
        return clamp(out, -1f, 1f);
    }

    private static float clamp(float v, float a, float b) {
        return Math.max(a, Math.min(b, v));
    }
}
