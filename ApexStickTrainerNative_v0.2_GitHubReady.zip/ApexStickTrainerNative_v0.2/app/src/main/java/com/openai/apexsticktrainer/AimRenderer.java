package com.openai.apexsticktrainer;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class AimRenderer implements GLSurfaceView.Renderer {
    private static final int TARGET_SEGMENTS = 40;
    private static final float EYE_Y = 1.65f;

    private final GameState state;
    private final ControllerInput input;

    private int program;
    private int aPos;
    private int uMvp;
    private int uColor;

    private final float[] proj = new float[16];
    private final float[] view = new float[16];
    private final float[] vp = new float[16];
    private final float[] mvp = new float[16];

    private final float[] cameraForward = new float[3];
    private final float[] cameraRight = new float[3];
    private final float[] cameraUp = new float[3];

    private final float[] circleVerts = new float[(TARGET_SEGMENTS + 2) * 3];
    private final FloatBuffer circleBuffer = ByteBuffer
            .allocateDirect(circleVerts.length * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer();

    private int surfaceW = 1;
    private int surfaceH = 1;
    private long lastNs;
    private boolean prevShoot;

    public AimRenderer(GameState state, ControllerInput input) {
        this.state = state;
        this.input = input;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig cfg) {
        // Minimal Aim-Lab-like void. No room geometry, no wall, no grid.
        GLES20.glClearColor(0.055f, 0.060f, 0.075f, 1f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);

        program = link(VS, FS);
        aPos = GLES20.glGetAttribLocation(program, "aPos");
        uMvp = GLES20.glGetUniformLocation(program, "uMvp");
        uColor = GLES20.glGetUniformLocation(program, "uColor");
        lastNs = System.nanoTime();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        surfaceW = Math.max(1, w);
        surfaceH = Math.max(1, h);
        GLES20.glViewport(0, 0, surfaceW, surfaceH);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNs) / 1_000_000_000f);
        lastNs = now;

        updateCameraFromController(dt);
        state.update(dt);

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        GLES20.glUseProgram(program);

        buildProjection();
        buildCamera();
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);

        if (state.mode == GameState.Mode.TRACKING) {
            drawTarget(state.tracking, 1.0f, 0.22f, 0.18f, 1f);
        } else {
            for (GameState.Target t : state.six) {
                drawTarget(t, 1.0f, 0.33f, 0.24f, 1f);
            }
        }
    }

    private void updateCameraFromController(float dt) {
        float x = strictLinearInput(input.getRightX());
        float y = strictLinearInput(input.getRightY());

        float dz = Math.max(0f, Math.min(0.30f, state.deadzone));
        if (dz > 0f) {
            x = remapDeadzone(x, dz);
            y = remapDeadzone(y, dz);
        }

        float sensitivity = input.isAdsPressed() ? state.adsSensitivity : state.hipSensitivity;
        float fullStickDegPerSec = Math.max(1f, state.degreesPerSecondPerSensitivity) * Math.max(0.01f, sensitivity);

        state.yaw = GameState.wrap180(state.yaw + x * fullStickDegPerSec * dt);
        state.pitch = GameState.clamp(state.pitch + y * fullStickDegPerSec * dt, -88f, 88f);

        boolean shoot = input.isShootPressed();
        if (shoot && !prevShoot) state.shootAtCenter();
        prevShoot = shoot;
    }

    private float strictLinearInput(float v) {
        // Explicit response control. exponent==1.0 is mathematically y=x.
        float e = GameState.clamp(state.responseExponent, 0.25f, 4f);
        if (Math.abs(e - 1f) < 0.0001f) return v;
        return Math.signum(v) * (float)Math.pow(Math.abs(v), e);
    }

    private static float remapDeadzone(float v, float dz) {
        float a = Math.abs(v);
        if (a <= dz) return 0f;
        float remapped = (a - dz) / (1f - dz);
        return Math.signum(v) * remapped;
    }

    private void buildProjection() {
        float aspect = surfaceW / (float)surfaceH;
        float hFov = GameState.clamp(state.fovDeg, 50f, 150f);

        // Convert requested horizontal FOV to the vertical FOV expected by Matrix.perspectiveM.
        float h = (float)Math.toRadians(hFov);
        float v = 2f * (float)Math.atan(Math.tan(h * 0.5f) / Math.max(0.1f, aspect));
        float vDeg = (float)Math.toDegrees(v);
        Matrix.perspectiveM(proj, 0, vDeg, aspect, 0.05f, 120f);
    }

    private void buildCamera() {
        float[] f = GameState.dirFromAngles(state.yaw, state.pitch);
        cameraForward[0] = f[0];
        cameraForward[1] = f[1];
        cameraForward[2] = f[2];

        // right = normalize(forward x worldUp)
        cameraRight[0] = -cameraForward[2];
        cameraRight[1] = 0f;
        cameraRight[2] = cameraForward[0];
        normalize(cameraRight);

        // up = right x forward
        cameraUp[0] = cameraRight[1] * cameraForward[2] - cameraRight[2] * cameraForward[1];
        cameraUp[1] = cameraRight[2] * cameraForward[0] - cameraRight[0] * cameraForward[2];
        cameraUp[2] = cameraRight[0] * cameraForward[1] - cameraRight[1] * cameraForward[0];
        normalize(cameraUp);

        Matrix.setLookAtM(view, 0,
                0f, EYE_Y, 0f,
                cameraForward[0], EYE_Y + cameraForward[1], cameraForward[2],
                cameraUp[0], cameraUp[1], cameraUp[2]);
    }

    private void drawTarget(GameState.Target t, float r, float g, float b, float a) {
        float[] dir = GameState.dirFromAngles(t.yawDeg, t.pitchDeg);
        float dist = Math.max(2f, t.distance);
        float cx = dir[0] * dist;
        float cy = EYE_Y + dir[1] * dist;
        float cz = dir[2] * dist;

        // Keep apparent angular size constant regardless of target distance.
        float radius = (float)Math.tan(Math.toRadians(state.targetAngularDiameter * 0.5f)) * dist;

        int k = 0;
        circleVerts[k++] = cx;
        circleVerts[k++] = cy;
        circleVerts[k++] = cz;

        for (int i = 0; i <= TARGET_SEGMENTS; i++) {
            float ang = (float)(Math.PI * 2.0 * i / TARGET_SEGMENTS);
            float co = (float)Math.cos(ang) * radius;
            float si = (float)Math.sin(ang) * radius;

            circleVerts[k++] = cx + cameraRight[0] * co + cameraUp[0] * si;
            circleVerts[k++] = cy + cameraRight[1] * co + cameraUp[1] * si;
            circleVerts[k++] = cz + cameraRight[2] * co + cameraUp[2] * si;
        }

        circleBuffer.position(0);
        circleBuffer.put(circleVerts);
        circleBuffer.position(0);

        // Vertices are already in world space, so VP is the complete transform.
        GLES20.glUniformMatrix4fv(uMvp, 1, false, vp, 0);
        GLES20.glUniform4f(uColor, r, g, b, a);

        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, circleBuffer);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, TARGET_SEGMENTS + 2);
        GLES20.glDisableVertexAttribArray(aPos);
    }

    private static void normalize(float[] v) {
        float len = (float)Math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
        if (len < 0.00001f) return;
        v[0] /= len; v[1] /= len; v[2] /= len;
    }

    private static int link(String vs, String fs) {
        int v = shader(GLES20.GL_VERTEX_SHADER, vs);
        int f = shader(GLES20.GL_FRAGMENT_SHADER, fs);
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, v);
        GLES20.glAttachShader(p, f);
        GLES20.glLinkProgram(p);
        return p;
    }

    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        return s;
    }

    private static final String VS =
            "attribute vec3 aPos;" +
            "uniform mat4 uMvp;" +
            "void main(){gl_Position=uMvp*vec4(aPos,1.0);}";

    private static final String FS =
            "precision mediump float;" +
            "uniform vec4 uColor;" +
            "void main(){gl_FragColor=uColor;}";
}
