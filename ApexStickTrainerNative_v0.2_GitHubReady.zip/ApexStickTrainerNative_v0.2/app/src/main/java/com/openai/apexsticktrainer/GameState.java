package com.openai.apexsticktrainer;

import java.util.Random;

public class GameState {
    public enum Mode { TRACKING, SIX_TARGETS }
    public enum SpeedMode { FIXED, RANDOM }

    public volatile Mode mode = Mode.TRACKING;
    public volatile SpeedMode speedMode = SpeedMode.RANDOM;

    // Display / camera. fovDeg is treated as horizontal FOV to avoid the extreme
    // fisheye effect caused by feeding 120 directly into a vertical-FOV matrix.
    public volatile float fovDeg = 120f;
    public volatile float hipSensitivity = 4f;
    public volatile float adsSensitivity = 3f;
    public volatile float degreesPerSecondPerSensitivity = 60f;
    public volatile float responseExponent = 1.00f; // 1.00 = strict linear
    public volatile float deadzone = 0f;

    // Tracking target moves continuously around the player on a full 360° ring.
    public volatile float fixedSpeed = 24f;
    public volatile float minSpeed = 10f;
    public volatile float maxSpeed = 42f;
    public volatile float randomInterval = 0.85f;
    public volatile float trackingRadius = 8.0f;
    public volatile float trackingPitchDeg = 0f;

    // Target appearance / six-target invisible boundary.
    public volatile float targetAngularDiameter = 1.55f;
    public volatile float sixBoundaryWidthDeg = 68f;
    public volatile float sixBoundaryHeightDeg = 38f;
    public volatile float sixTargetDistance = 9.0f;

    // Camera angles use the same convention as the renderer:
    // +yaw = turn right, +pitch = look down.
    public volatile float yaw = 0f;
    public volatile float pitch = 0f;
    public volatile int shots = 0;
    public volatile int hits = 0;

    public static class Target {
        public float yawDeg;
        public float pitchDeg;
        public float distance;
        public boolean active = true;
    }

    public final Target tracking = new Target();
    public final Target[] six = new Target[6];
    public final Random rng = new Random();

    private float trackingSpeedSigned = 24f;
    private float randomTimer = 0f;
    private float sixCenterYaw = 0f;
    private float sixCenterPitch = 0f;

    public GameState() {
        for (int i = 0; i < six.length; i++) six[i] = new Target();
        resetTargets();
    }

    public synchronized void resetTargets() {
        if (mode == Mode.TRACKING) {
            tracking.yawDeg = wrap180(yaw + 18f);
            tracking.pitchDeg = trackingPitchDeg;
            tracking.distance = trackingRadius;
            trackingSpeedSigned = Math.max(0.1f, fixedSpeed);
            randomTimer = 0f;
        } else {
            // The invisible six-target volume is centered on wherever the player
            // is looking when the drill is entered/reset.
            sixCenterYaw = yaw;
            sixCenterPitch = clamp(pitch, -55f, 55f);
            for (Target t : six) respawnSix(t);
        }
    }

    public synchronized void update(float dt) {
        if (mode != Mode.TRACKING) return;

        tracking.distance = Math.max(2.0f, trackingRadius);
        tracking.pitchDeg = trackingPitchDeg;

        if (speedMode == SpeedMode.RANDOM) {
            randomTimer -= dt;
            if (randomTimer <= 0f) {
                chooseRandomTrackingSpeed();
                randomTimer = Math.max(0.12f, randomInterval);
            }
        } else {
            float sign = trackingSpeedSigned < 0f ? -1f : 1f;
            trackingSpeedSigned = sign * Math.max(0.1f, fixedSpeed);
        }

        tracking.yawDeg = wrap180(tracking.yawDeg + trackingSpeedSigned * dt);
    }

    public synchronized boolean shootAtCenter() {
        shots++;
        boolean hit = false;

        if (mode == Mode.TRACKING) {
            hit = angularDistanceToCamera(tracking) <= targetAngularDiameter * 0.5f;
            if (hit) hits++;
        } else {
            for (Target t : six) {
                if (angularDistanceToCamera(t) <= targetAngularDiameter * 0.5f) {
                    hit = true;
                    hits++;
                    respawnSix(t);
                    break;
                }
            }
        }
        return hit;
    }

    public synchronized float getTrackingSpeedSigned() {
        return trackingSpeedSigned;
    }

    public synchronized float getSixCenterYaw() { return sixCenterYaw; }
    public synchronized float getSixCenterPitch() { return sixCenterPitch; }

    private float angularDistanceToCamera(Target t) {
        float[] a = dirFromAngles(yaw, pitch);
        float[] b = dirFromAngles(t.yawDeg, t.pitchDeg);
        float dot = clamp(a[0]*b[0] + a[1]*b[1] + a[2]*b[2], -1f, 1f);
        return (float)Math.toDegrees(Math.acos(dot));
    }

    private void chooseRandomTrackingSpeed() {
        float lo = Math.min(minSpeed, maxSpeed);
        float hi = Math.max(minSpeed, maxSpeed);
        float mag = lerp(Math.max(0.1f, lo), Math.max(0.1f, hi), rng.nextFloat());

        // Random mode changes both magnitude and direction. Keeping each choice
        // until the next interval creates readable tracking changes without teleporting.
        float sign = rng.nextBoolean() ? 1f : -1f;
        trackingSpeedSigned = sign * mag;
    }

    private void respawnSix(Target t) {
        float halfW = Math.max(4f, sixBoundaryWidthDeg * 0.5f);
        float halfH = Math.max(3f, sixBoundaryHeightDeg * 0.5f);

        t.yawDeg = wrap180(sixCenterYaw + lerp(-halfW, halfW, rng.nextFloat()));
        t.pitchDeg = clamp(sixCenterPitch + lerp(-halfH, halfH, rng.nextFloat()), -72f, 72f);
        t.distance = Math.max(3f, sixTargetDistance);
        t.active = true;
    }

    public static float[] dirFromAngles(float yawDeg, float pitchDeg) {
        float y = (float)Math.toRadians(yawDeg);
        float p = (float)Math.toRadians(pitchDeg);
        float cp = (float)Math.cos(p);
        return new float[]{
                cp * (float)Math.sin(y),
                -(float)Math.sin(p),
                -cp * (float)Math.cos(y)
        };
    }

    public static float wrap180(float x) {
        while (x > 180f) x -= 360f;
        while (x < -180f) x += 360f;
        return x;
    }

    public static float clamp(float v, float a, float b) {
        return Math.max(a, Math.min(b, v));
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }
}
