package com.openai.apexsticktrainer;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class GameSurfaceView extends GLSurfaceView {
    public final AimRenderer renderer;

    public GameSurfaceView(Context context, GameState state, ControllerInput input) {
        super(context);
        setEGLContextClientVersion(2);
        renderer = new AimRenderer(state, input);
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
}
